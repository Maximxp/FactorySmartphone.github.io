﻿using Abstract.Displays;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract.Classes
{
    class TFT : Display
    {
        public override void Display_Show()
        {
            Console.WriteLine("Дисплей: TFT");
        }
    }
}

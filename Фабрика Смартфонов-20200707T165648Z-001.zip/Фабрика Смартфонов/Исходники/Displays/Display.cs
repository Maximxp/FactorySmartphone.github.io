﻿using Abstract.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract.Displays
{
    abstract class Display
    {
        public abstract void Display_Show();
    }
}

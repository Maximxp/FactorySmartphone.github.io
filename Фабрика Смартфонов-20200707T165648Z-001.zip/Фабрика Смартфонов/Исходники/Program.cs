﻿using Abstract.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Abstract
{
    class Program
    {
        static void Main(string[] args)
        {

            Smartphone smartphone1 = new Smartphone(new AndroidSmartphone());
            Console.WriteLine("№1");
            smartphone1.Show();
            Smartphone smartphone2 = new Smartphone(new IOSSmartphone());
            Console.WriteLine("№2");
            smartphone2.Show();
            Smartphone smartphone3 = new Smartphone(new WindowsSmartphone());
            Console.WriteLine("№3");
            smartphone3.Show();


            Console.ReadKey();
        }
      
    }
}

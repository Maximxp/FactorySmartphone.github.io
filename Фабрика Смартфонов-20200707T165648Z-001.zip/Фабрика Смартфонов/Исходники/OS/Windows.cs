﻿using Abstract.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract.Classes
{
    class Windows : OS
    {
        public override void OS_Show()
        {
            Console.WriteLine("ОС: Windows");
        }
    }
}

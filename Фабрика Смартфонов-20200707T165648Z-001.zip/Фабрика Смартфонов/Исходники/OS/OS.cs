﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract.Classes
{
    abstract class OS
    {
        public abstract void OS_Show();
    }
}

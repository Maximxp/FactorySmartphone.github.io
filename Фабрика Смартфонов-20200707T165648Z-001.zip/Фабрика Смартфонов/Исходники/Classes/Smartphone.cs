﻿using Abstract.Displays;
using Abstract.Processors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abstract.Classes
{
    class Smartphone
    {
        private OS oS;
        private Processor processor;
        private Display display;
        public Smartphone(FactorySmartphone factorySmartphone)
        {
            oS = factorySmartphone.Create_OS();
            processor = factorySmartphone.Create_Processor();
            display = factorySmartphone.Create_Display();
        }
        public void Show()
        {
            Console.WriteLine();
            Console.WriteLine("Смартфон создан");
            oS.OS_Show();
            processor.Processor_Show();
            display.Display_Show();
        }
    }
}

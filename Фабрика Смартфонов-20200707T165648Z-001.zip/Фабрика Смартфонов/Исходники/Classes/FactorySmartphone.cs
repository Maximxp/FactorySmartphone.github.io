﻿using Abstract.Displays;
using Abstract.Processors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract.Classes
{
    abstract class FactorySmartphone
    {
        public abstract OS Create_OS();
        public abstract Processor Create_Processor();
        public abstract Display Create_Display();

    }
}

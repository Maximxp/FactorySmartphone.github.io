﻿using Abstract.Displays;
using Abstract.Processors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract.Classes
{
    class WindowsSmartphone : FactorySmartphone
    {
        public override Display Create_Display()
        {
            return new LCD();
        }

        public override OS Create_OS()
        {
            return new Windows();
        }

        public override Processor Create_Processor()
        {
            return new Qualcomm();
        }
    }
}

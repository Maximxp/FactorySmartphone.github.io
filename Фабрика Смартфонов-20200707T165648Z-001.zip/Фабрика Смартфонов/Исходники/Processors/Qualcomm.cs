﻿using Abstract.Processors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract.Classes
{
    class Qualcomm : Processor
    {
        public override void Processor_Show()
        {
            Console.WriteLine("Процессор: Qualcomm");
        }
    }
}

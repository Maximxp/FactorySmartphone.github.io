﻿using Abstract.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract.Processors
{
    class Exynos : Processor
    {
        public override void Processor_Show()
        {
            Console.WriteLine("Процессор: Exynos");
        }
    }
}
